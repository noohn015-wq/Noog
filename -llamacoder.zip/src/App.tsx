import { useState } from "react";
import { HomePage } from "@/components/HomePage";
import { AccountPage } from "@/components/AccountPage";
import { OrdersPage } from "@/components/OrdersPage";
import { ComplaintsPage } from "@/components/ComplaintsPage";
import { BottomNav } from "@/components/BottomNav";
import { LanguageToggle } from "@/components/LanguageToggle";
import { translations } from "@/lib/i18n";

export default function App() {
  const [lang, setLang] = useState<"ar" | "en">("ar");
  const [page, setPage] = useState<"home" | "orders" | "account" | "complaints">("home");

  const t = translations[lang];

  return (
    <div dir={lang === "ar" ? "rtl" : "ltr"} className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <div className="relative mx-auto min-h-screen max-w-md bg-slate-50 shadow-2xl shadow-slate-300/20 dark:bg-slate-900 dark:shadow-black/20">
        <div className="absolute end-4 top-4 z-50">
          <LanguageToggle lang={lang} setLang={setLang} />
        </div>

        {page === "home" && <HomePage t={t} lang={lang} />}
        {page === "orders" && <OrdersPage t={t} lang={lang} />}
        {page === "account" && <AccountPage t={t} lang={lang} />}
        {page === "complaints" && <ComplaintsPage t={t} lang={lang} />}

        <BottomNav page={page} setPage={setPage} t={t} />
      </div>
    </div>
  );
}